//
//  Country.m
//  Countries
//
//  Created by Ignacio Romero Z. on 6/22/14.
//  Copyright (c) 2014 DZN Labs. All rights reserved.
//

#import "Country.h"


@implementation Country

@dynamic name;
@dynamic code;

@end
